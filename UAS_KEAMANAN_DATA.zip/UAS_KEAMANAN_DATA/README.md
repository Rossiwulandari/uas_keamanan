# Tugas Kriptografi dan Steganografi

Tugas ini berisi implementasi dari beberapa teknik kriptografi dan steganografi, termasuk:
1. Caesar Cipher: Enkripsi menggunakan algoritma Caesar Cipher.
2. DES (Data Encryption Standard): Enkripsi menggunakan algoritma DES.
3. Steganografi: Menyembunyikan pesan dalam gambar menggunakan metode steganografi.

## Cara Menjalankan

### Persyaratan
- Python 3.x
- Pustaka-pustaka yang diperlukan:
  - `Pillow` untuk steganografi
  - `pycryptodome` untuk DES
  - `bitarray` untuk konversi pesan ke bit

### Instalasi
1. Install pustaka-pustaka yang dibutuhkan:
   ```bash
   pip install pillow pycryptodome bitarray
   ```

2. Jalankan setiap script Python sesuai dengan kebutuhan:
   - Untuk Caesar Cipher:
     ```bash
     python chipergui.py
     ```
   - Untuk DES:
     ```bash
     python desgui.py
     ```
   - Untuk Steganografi:
     ```bash
     python steganogui.py
     ```

## Penjelasan
- Caesar Cipher: Menggunakan teknik pergeseran alfabet untuk mengenkripsi pesan.
- DES: Menggunakan algoritma simetris untuk mengenkripsi pesan.
- Steganografi: Menyembunyikan pesan teks di dalam gambar.
# pratikum_keamanan_data
