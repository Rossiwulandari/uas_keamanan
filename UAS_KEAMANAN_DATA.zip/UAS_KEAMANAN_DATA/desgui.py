from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

# Fungsi untuk mengenkripsi data menggunakan DES
def des_encrypt(plain_text, key):
    # Pastikan kunci memiliki panjang 8 byte (64-bit) untuk DES
    cipher = DES.new(key, DES.MODE_CBC)  # Menggunakan mode CBC (Cipher Block Chaining)
    
    # Padding untuk memastikan panjang data merupakan kelipatan 8
    padded_data = pad(plain_text.encode(), DES.block_size)
    
    # Melakukan enkripsi
    encrypted_data = cipher.encrypt(padded_data)
    
    # Mengembalikan IV (Initialization Vector) dan data terenkripsi
    return cipher.iv + encrypted_data

# Fungsi untuk mendekripsi data menggunakan DES
def des_decrypt(encrypted_data, key):
    # Mengambil IV dari data terenkripsi
    iv = encrypted_data[:DES.block_size]
    cipher = DES.new(key, DES.MODE_CBC, iv)
    
    # Data terenkripsi tanpa IV
    encrypted_text = encrypted_data[DES.block_size:]
    
    # Melakukan dekripsi dan menghapus padding
    decrypted_data = unpad(cipher.decrypt(encrypted_text), DES.block_size)
    
    return decrypted_data.decode()

# Contoh penggunaan
if __name__ == "__main__":
    plain_text = input("Masukkan teks yang ingin dienkripsi: ")
    
    # Kunci harus panjangnya 8 byte (64 bit)
    key = get_random_bytes(8)  # Menghasilkan kunci acak 8 byte
    
    print(f"Kunci: {key.hex()}")
    
    # Enkripsi
    encrypted_data = des_encrypt(plain_text, key)
    print(f"Data terenkripsi: {encrypted_data.hex()}")
    
    # Dekripsi
    decrypted_text = des_decrypt(encrypted_data, key)
    print(f"Data terdekripsi: {decrypted_text}")
