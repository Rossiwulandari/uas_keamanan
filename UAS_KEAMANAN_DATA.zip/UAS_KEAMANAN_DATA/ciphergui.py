# Fungsi untuk mengenkripsi teks menggunakan Caesar Cipher
def caesar_encrypt(plain_text, shift):
    encrypted_text = ''
    
    # Mengulangi setiap karakter dalam plain_text
    for char in plain_text:
        # Mengecek apakah karakter adalah huruf besar
        if char.isupper():
            # Menggeser huruf besar
            encrypted_text += chr((ord(char) + shift - 65) % 26 + 65)
        # Mengecek apakah karakter adalah huruf kecil
        elif char.islower():
            # Menggeser huruf kecil
            encrypted_text += chr((ord(char) + shift - 97) % 26 + 97)
        else:
            # Menambahkan karakter selain huruf tanpa perubahan
            encrypted_text += char
    
    return encrypted_text

# Fungsi untuk mendekripsi teks menggunakan Caesar Cipher
def caesar_decrypt(encrypted_text, shift):
    decrypted_text = ''
    
    # Mengulangi setiap karakter dalam encrypted_text
    for char in encrypted_text:
        # Mengecek apakah karakter adalah huruf besar
        if char.isupper():
            # Menggeser huruf besar
            decrypted_text += chr((ord(char) - shift - 65) % 26 + 65)
        # Mengecek apakah karakter adalah huruf kecil
        elif char.islower():
            # Menggeser huruf kecil
            decrypted_text += chr((ord(char) - shift - 97) % 26 + 97)
        else:
            # Menambahkan karakter selain huruf tanpa perubahan
            decrypted_text += char
    
    return decrypted_text

# Contoh penggunaan
if __name__ == "__main__":
    plain_text = input("Masukkan teks yang ingin dienkripsi: ")
    shift = int(input("Masukkan jumlah pergeseran (shift): "))

    # Enkripsi teks
    encrypted_text = caesar_encrypt(plain_text, shift)
    print(f"Teks terenkripsi: {encrypted_text}")
    
    # Dekripsi teks
    decrypted_text = caesar_decrypt(encrypted_text, shift)
    print(f"Teks terdekripsi: {decrypted_text}")
