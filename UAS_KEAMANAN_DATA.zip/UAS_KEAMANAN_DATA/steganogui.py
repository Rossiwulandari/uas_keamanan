from PIL import Image
from bitarray import bitarray

# Fungsi untuk menyembunyikan pesan dalam gambar
def hide_message(image_path, message, output_image_path):
    # Ubah pesan menjadi bit array
    message_bits = bitarray()
    message_bits.frombytes(message.encode())
    
    # Buka gambar menggunakan PIL
    img = Image.open(image_path)
    
    # Pastikan gambar memiliki mode RGB
    img = img.convert("RGB")
    
    # Mendapatkan data piksel dari gambar
    pixels = img.load()
    
    # Periksa panjang pesan untuk memastikan bahwa pesan tidak lebih besar dari kapasitas gambar
    message_length = len(message_bits)
    if message_length > img.width * img.height * 3:
        raise ValueError("Pesan terlalu besar untuk gambar ini")
    
    bit_index = 0
    for y in range(img.height):
        for x in range(img.width):
            # Ambil warna RGB dari piksel
            r, g, b = pixels[x, y]
            
            # Jika masih ada bit yang perlu disembunyikan
            if bit_index < message_length:
                # Ambil bit berikutnya dari pesan
                r_bit = message_bits[bit_index]  # Bit untuk merah
                g_bit = message_bits[bit_index + 1] if bit_index + 1 < message_length else 0  # Bit untuk hijau
                b_bit = message_bits[bit_index + 2] if bit_index + 2 < message_length else 0  # Bit untuk biru
                
                # Modifikasi RGB untuk menyembunyikan bit dalam LSB (Least Significant Bit)
                r = (r & 0xFE) | r_bit
                g = (g & 0xFE) | g_bit
                b = (b & 0xFE) | b_bit
                
                # Update piksel dengan warna yang sudah dimodifikasi
                pixels[x, y] = (r, g, b)
                
                # Update indeks bit
                bit_index += 3
            
            # Jika seluruh pesan sudah disembunyikan, keluar dari loop
            if bit_index >= message_length:
                break
        if bit_index >= message_length:
            break
    
    # Simpan gambar baru dengan pesan tersembunyi
    img.save(output_image_path)

# Fungsi untuk mengambil pesan dari gambar yang telah disembunyikan
def extract_message(image_path):
    # Buka gambar dengan PIL
    img = Image.open(image_path)
    
    # Pastikan gambar memiliki mode RGB
    img = img.convert("RGB")
    
    # Mendapatkan data piksel dari gambar
    pixels = img.load()
    
    message_bits = bitarray()
    
    for y in range(img.height):
        for x in range(img.width):
            r, g, b = pixels[x, y]
            
            # Ambil LSB dari setiap warna piksel
            message_bits.append(r & 1)
            message_bits.append(g & 1)
            message_bits.append(b & 1)
    
    # Konversi bit array menjadi bytes (pesan)
    message_bytes = message_bits.tobytes()
    message = message_bytes.decode(errors="ignore")
    
    return message

# Contoh penggunaan
if __name__ == "__main__":
    original_image = "input_